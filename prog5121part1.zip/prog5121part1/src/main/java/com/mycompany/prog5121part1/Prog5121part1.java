/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121part1;
import java.util.ArrayList;
import java.util.Scanner;
import java.security.SecureRandom;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author Grade12teacher
 */
public class Prog5121part1 {

    public static void main(String[] args) {
        // A Scanner object that reads input
        Scanner scanner = new Scanner(System.in);
        ArrayList<Login> users = new ArrayList<>();
        
        System.out.println("===WELCOME===");
        
        while (true) {
            //the following is the menu
            System.out.println("Main Manu");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.println("Select an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();//consume newline character
            
            switch (choice) {
                case 1: //The registration
                    System.out.println("Enter Username: ");
                    String username = scanner.nextLine();
                    System.out.println("Username successfully captured!");
                    
                    //verifying username
                    boolean validUsername = username.contains("_") && username.length() <= 5;
                    if (validUsername) {
                        System.out.println("Username must contain at least one underscore (_) and no more than 5 characters long");
                        break;
                    }
                    
                    System.out.println("Enter password");
                    String password = scanner.nextLine();
                    System.out.println("Password successfully captured");
                    
                    //verifying password
                    boolean validPassword = password.length() >=8 &&
                                            password.matches(".*[A-Z].*") &&
                                            password.matches(".*[£$%^&]");
                    
                    if (!validPassword) {
                        System.out.println("Password must at least be eight characters long, contains a capital letter, contains a number, contains a special character");
                        break;
                    }
                    
                    System.out.println("Enter South African phone number (e.g +27690605422)");
                    String phoneNumber = scanner.nextLine();
                    System.out.println("Cell phone number successfully added");
                    
                    //verifying cell phone number
                    String regex = "+27[6-8]";
                    if (!phoneNumber.matches(regex)) {
                        System.out.println("Invalid phone number format! use +27xxxxxxxxx");
                        break;
                    }
                    //cheching if the user already exists
                    boolean userExists = users.stream().anyMatch(u->u.getUsername().eguals(username));
                    if (userExists) {
                        System.out.println("Username already exists. Please choose another username.");
                        break;
                    }
                    //adding a new user
                    users.add(new Login(username, password, phoneNumber));
                    System.out.println("User registered successfully!");
                    //Welcome the new user
                    System.out.println("Welcome "+ username + "!You can now login");
                    System.out.println("Redirecting you to login page ......");
                    
                    //immediately prompt the user to login
                    promptLogin(scanner, users);
                    break;
                    
                case 2://login
                    if (users.isEmpty()) {
                        System.out.println("No users are registered. Please register first.");
                        break;
                    }
                    //prompt the user to login
                    promptLogin(scanner,users);
                    break;
                    
                case 3://the exit
                    System.out.println("Goodbye!!");
                    scanner.close();
                    return;
                    
                    
                default:
                    System.out.println("Invalid option. Please choose 1,2 or 3");
            }
        }
    }

     //ways that handle login logic
    private static void promptLogin(Scanner scanner,ArrayList<Login>users) {
        System.out.print("Enter username: ");
        String enteredUsername = scanner.nextLine();
        System.out.print("Enter password: ");
        String enteredPassword = scanner.nextLine();
        
        Login user = users.stream().filter(u->u.getUsername().eguals(enteredUsername)).findFirst().orElse(null);
        
        boolean loginStatus = user != null && user.loginUser(enteredPassword);
        System.out.println(user !=null? user.returnLoginStatus(loginStatus):"User not found.");
    }
}
//Login class
class Login {
    public String username;
    public String passwordHash;
    public String phoneNumber;
    public byte[]salt;
    
    public  Login(String username, String password, String phoneNumber) {
        this.username = username;
        this.salt = generateSalt();
        this.passwordHash = hashPassword(password,salt);
        this.phoneNumber = phoneNumber;
    }
    public String getUsername(){
        return username;
    }
    public boolean loginUser(String enteredPassword){
        return this.passwordHash.eguals(hashPassword(enteredPassword, salt));
    }
    public String returningLoginStatus(boolean status){
        return status?"Login successful! ":"Invalid username or password.";
    }
    //hash password with salt using SHA-256
    private String hashPassword(String password, byte[]salt){
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);//add salt to the hash
            byte[]hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for(byte b = 0; hash) {
                hexString.append = append(String.format("%02x", b));
                
            }
            return hexString.toString();
        }catch(NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
        
    }
    //Generate a random salt for password hashing
    private byte[]generateSalt(){
        try{
            SecureRandom random = new SecureRandom();
            byte[]salt = new byte[16];
            random.nextBytes(salt);
            return salt;
            
        }catch(Exception e){
            throw new RuntimeException("Error generating salt",e);
        }
    }
}
    

